#!/bin/bash
TEST_FILE=$1
TEST_FILE2="$1"_fsg

if [ -f  $TEST_FILE ]; then
    if [ ! -f  $TEST_FILE2 ]; then
        sed -e 's/e/u/g' $TEST_FILE > $TEST_FILE2
    fi
    python plot.py $TEST_FILE --supports 95 50 25 10 5
else
    echo "Can't find $TEST_FILE"
fi 
