#!/bin/sh
make clean
make all