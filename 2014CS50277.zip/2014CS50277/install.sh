#!/bin/sh

REPO="https://github.com/ankush-phulia/Data-Mining.git"
git clone $REPO
sudo pip install -r requirements.txt